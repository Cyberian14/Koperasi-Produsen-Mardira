<div class="row">
    <div class="col col-md-12 text-center">
        <span class="modal-icon display-2-lg">
            <img src="assets/img/question.gif" width="70%">
        </span>
    </div>
</div>
<div class="row">
    <div class="col col-md-12 text-center mb-3">
        <small class="modal-title my-3">
            Dengan memilih lanjutkan, anda akan diarahkan ke halaman tambah data pembayaran.
            Apakah anda akan melanjutkan ke halaman tersebut?
        </small>
    </div>
</div>
