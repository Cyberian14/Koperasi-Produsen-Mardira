<div class="modal-body">
    <div class="row">
        <div class="col col-md-12 text-center">
            <span class="modal-icon display-2-lg">
                <img src="assets/img/question.gif" width="70%">
            </span>
        </div>
    </div>
    <div class="row">
        <div class="col col-md-12 text-center mb-3">
            <small class="modal-title my-3">Apakah anda yakin ingin export data ini?</small>
        </div>
    </div>
</div>
<div class="modal-footer bg-success">
    <div class="row">
        <div class="col-md-12 mb-2">
            <a href="_Page/BagiHasil/ProsesExportBagiHasil.php" class="btn btn-primary btn-rounded" target="_blank">
                <i class="bi bi-download"></i> Export
            </a>
            <button type="button" class="btn btn-dark btn-rounded" data-bs-dismiss="modal">
                <i class="bi bi-x-circle"></i> Tutup
            </button>
        </div>
    </div>
</div>