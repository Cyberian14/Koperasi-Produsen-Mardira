<?php
    if(!empty($_POST['id_shu_session'])){
        $id_shu_session=$_POST['id_shu_session'];
?>
<div class="row">
        <div class="col col-md-12 text-center">
            <span class="modal-icon display-2-lg">
                <img src="assets/img/question.gif" width="70%">
            </span>
        </div>
    </div>
    <div class="row">
        <div class="col col-md-12 text-center mb-3">
            <small class="modal-title my-3" id="NotifikasiHapusSemuaJurnal">Apakah anda yakin akan menghapus semua jurnal ini?</small>
        </div>
    </div>
</div>
<?php 
    }else{
        $id_shu_session="";
        echo '<div class="modal-body">';
        echo '  <div class="row">';
        echo '      <div class="col col-md-12 text-center">';
        echo '          <small class="modal-title my-3">Sorry, No access data selected.</small>';
        echo '      </div>';
        echo '  </div>';
        echo '</div>';
    }
?>