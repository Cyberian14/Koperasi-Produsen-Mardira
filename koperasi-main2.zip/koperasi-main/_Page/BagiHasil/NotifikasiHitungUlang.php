<div class="alert alert-danger alert-dismissible fade show" role="alert">
    Dengan memilih <i>Hitung Ulang</i> maka perubahan pada rincian bagi hasil akan ikut berubah.
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>