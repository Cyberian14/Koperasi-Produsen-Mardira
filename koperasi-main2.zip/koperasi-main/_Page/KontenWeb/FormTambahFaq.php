<?php 
    date_default_timezone_set("Asia/Jakarta");
?>
<div class="row">
    <div class="col-md-12 mb-3">
        <label for="pertanyaan">Pertanyaan</label>
        <textarea name="pertanyaan" id="pertanyaan" cols="30" rows="3" class="form-control"></textarea>
    </div>
</div>
<div class="row">
    <div class="col-md-12 mb-3">
        <label for="jawaban">Jawaban</label>
        <textarea name="jawaban" id="jawaban" cols="30" rows="3" class="form-control"></textarea>
    </div>
</div>
<div class="row">
    <div class="col-md-12 mb-3" id="NotifikasiTambahFaq">
        <small class="credit text-primary">Pastikan FAQ Yang Anda Input Sudah Benar</small>
    </div>
</div>