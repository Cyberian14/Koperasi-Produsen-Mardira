<option value="Pimpinan">Pimpinan</option>
<option value="Administrator">Administrator</option>
<option value="Front Officer">Front Officer</option>
<option value="Medical Personnel">Medical Personnel</option>