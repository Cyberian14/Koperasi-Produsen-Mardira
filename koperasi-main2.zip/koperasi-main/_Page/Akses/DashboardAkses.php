<div class="row">
    <div class="col-md-12">
        <div class="card">
            
        </div>
    </div>
</div>