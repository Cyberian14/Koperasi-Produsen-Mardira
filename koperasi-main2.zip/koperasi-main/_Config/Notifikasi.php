<?php
    //Menghitung Notifikasi Admin
    $JumlahNotifikasi=mysqli_num_rows(mysqli_query($Conn, "SELECT*FROM notifikasi"));
?>