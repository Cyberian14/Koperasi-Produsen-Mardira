Spesifikasi Aplikasi
1. Versi PHP 7.4.9
2. MySql 5.7.31

Instalasi
1. Import Database di Directory db/koperasi.sql
2. Sebelum di gunakan boleh hapus record contoh yang sudah ada kecuali pada tabel: Setting
3. Akun akses admin pertama kali dhiforester@gmail.com & pass: dhiforester
